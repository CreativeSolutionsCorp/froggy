﻿import React, { useState, useEffect, useRef } from 'react';
import { StyleSheet, Text, View, TextInput, TouchableOpacity, ScrollView, Dimensions } from 'react-native';
import Animated, { Easing, useSharedValue, useAnimatedStyle, withTiming, withSequence, withRepeat } from 'react-native-reanimated';
import { LinearGradient } from 'expo-linear-gradient';
import Svg, { Circle, Defs, Ellipse, G, Line, Path, Polygon, RadialGradient, Rect, Stop, Text as SvgText } from 'react-native-svg';

const { width, height } = Dimensions.get('window');

const JARGON_BANK = [
  "INBOUND_REQUEST: Allocating isolated virtualization sandbox...",
  "STATUS: Secure proxy gateway locked to zero-trust route.",
  "HEURISTIC_SCAN: Initializing deep abstract syntax tree parse...",
  "PAYLOAD_ANALYSIS: Deconstructing binary payload streams...",
  "DEPS_MAP: Resolving nested dependency graph and maintainer keys...",
  "VECTOR_CHECK: Correlating structure hashes with threat databases...",
  "ENTROPY_DETECTION: Sampling obfuscated code blocks...",
  "BEHAVIORAL_MODEL: Simulating runtime mutation signatures...",
  "INTEGRITY_SHIELD: Verifying publisher provenance and signatures...",
  "RADAR_GRID: Sweeping artifact perimeter for crimson anomalies...",
  "PORTAL_CORE: Charging containment ring for final verdict..."
];

const TERMINAL_INTERVAL_MS = 110;
const THREAT_NAMES = ['malware', 'trojan', 'ransomware', 'worm', 'rootkit', 'threat', 'virus'];
const SAFE_ARTIFACTS = ['react', 'lodash', 'quantum'];
const IDLE_LOGS = [
  '>> QUANTUM_FROG.v3 diagnostic spine online',
  '>> radar.grid.rotate = true',
  '>> artifact ingress port awaiting payload',
  '>> matrix entropy sampler standing by'
];

const FrogAvatar = ({ digitColor, glowColor }) => (
  <View style={styles.frogAvatarShell}>
    <Svg width="100%" height="100%" viewBox="0 0 180 180">
      <Defs>
        <RadialGradient id="frogAura" cx="50%" cy="48%" r="56%">
          <Stop offset="0%" stopColor={glowColor} stopOpacity="0.34" />
          <Stop offset="68%" stopColor="#061a18" stopOpacity="0.08" />
          <Stop offset="100%" stopColor="#000000" stopOpacity="0" />
        </RadialGradient>
      </Defs>
      <Circle cx="90" cy="88" r="82" fill="url(#frogAura)" />
      <Path d="M47 151 C54 118 69 106 90 106 C111 106 126 118 133 151 Z" fill="#07231f" stroke={glowColor} strokeWidth="2" />
      <Path d="M61 136 L73 119 L90 128 L107 119 L119 136 L109 159 L71 159 Z" fill="#0a3430" stroke="#00ff66" strokeOpacity="0.42" strokeWidth="1.4" />
      <Circle cx="55" cy="55" r="27" fill="#0a3a2f" stroke={glowColor} strokeWidth="2" />
      <Circle cx="125" cy="55" r="27" fill="#0a3a2f" stroke={glowColor} strokeWidth="2" />
      <Ellipse cx="90" cy="82" rx="55" ry="48" fill="#0b4235" stroke="#00f0ff" strokeOpacity="0.72" strokeWidth="2.2" />
      <Circle cx="55" cy="54" r="12" fill="#d7fff6" />
      <Circle cx="125" cy="54" r="12" fill="#d7fff6" />
      <Circle cx="58" cy="56" r="5" fill="#00100f" />
      <Circle cx="122" cy="56" r="5" fill="#00100f" />
      <Path d="M70 97 C81 106 99 106 110 97" stroke="#00ff66" strokeOpacity="0.82" strokeWidth="3" fill="none" strokeLinecap="round" />
      <Path d="M72 70 L58 78 L72 85" stroke="#00f0ff" strokeOpacity="0.72" strokeWidth="2" fill="none" strokeLinecap="round" />
      <Path d="M108 70 L122 78 L108 85" stroke="#ff0055" strokeOpacity="0.72" strokeWidth="2" fill="none" strokeLinecap="round" />
      <Polygon points="78,38 102,38 109,69 90,80 71,69" fill="#031817" stroke={glowColor} strokeWidth="2" />
      <Line x1="90" y1="22" x2="90" y2="38" stroke={glowColor} strokeWidth="2" strokeLinecap="round" />
      <Circle cx="90" cy="20" r="4" fill={digitColor} />
      <SvgText x="90" y="67" textAnchor="middle" fontFamily="Courier" fontSize="38" fontWeight="900" fill={digitColor} opacity="0.3" stroke={digitColor} strokeWidth="5">
        3
      </SvgText>
      <SvgText x="90" y="67" textAnchor="middle" fontFamily="Courier" fontSize="38" fontWeight="900" fill={digitColor} stroke={digitColor} strokeWidth="0.8">
        3
      </SvgText>
      <Path d="M48 126 L28 139 M132 126 L152 139 M69 145 L56 164 M111 145 L124 164" stroke={glowColor} strokeOpacity="0.58" strokeWidth="2.4" strokeLinecap="round" />
      <Rect x="75" y="134" width="30" height="10" rx="2" fill="#020607" stroke={digitColor} strokeOpacity="0.65" />
    </Svg>
  </View>
);

const RadarGrid = () => (
  <Svg width="100%" height="100%" viewBox="0 0 600 600" preserveAspectRatio="xMidYMid slice">
    <Defs>
      <RadialGradient id="radarFade" cx="50%" cy="50%" r="50%">
        <Stop offset="0%" stopColor="#00f0ff" stopOpacity="0.14" />
        <Stop offset="52%" stopColor="#00ff66" stopOpacity="0.06" />
        <Stop offset="100%" stopColor="#000000" stopOpacity="0" />
      </RadialGradient>
    </Defs>
    <Rect width="600" height="600" fill="url(#radarFade)" />
    <G opacity="0.34" stroke="#00f0ff" strokeWidth="1">
      {[90, 150, 210, 270].map(radius => (
        <Circle key={radius} cx="300" cy="300" r={radius} fill="none" strokeDasharray="3 14" />
      ))}
      {[0, 30, 60, 90, 120, 150].map(angle => {
        const radians = (angle * Math.PI) / 180;
        const x = 300 + Math.cos(radians) * 285;
        const y = 300 + Math.sin(radians) * 285;
        const x2 = 300 - Math.cos(radians) * 285;
        const y2 = 300 - Math.sin(radians) * 285;
        return <Line key={angle} x1={x2} y1={y2} x2={x} y2={y} opacity="0.32" />;
      })}
    </G>
    <Path d="M300 300 L300 16 A284 284 0 0 1 529 132 Z" fill="#00ff66" opacity="0.08" />
  </Svg>
);

export default function App() {
  const [input, setInput] = useState('');
  const [appState, setAppState] = useState('IDLE'); // IDLE, SCANNING, SAFE, BURNT
  const [terminalLogs, setTerminalLogs] = useState([]);
  const [digitFlash, setDigitFlash] = useState(false);
  
  // Animation Triggers
  const shakeX = useSharedValue(0);
  const shakeY = useSharedValue(0);
  const portalScale = useSharedValue(1);
  const portalShakeX = useSharedValue(0);
  const portalShakeY = useSharedValue(0);
  const radarRotation = useSharedValue(0);
  const flashOpacity = useSharedValue(0);
  const scrollViewRef = useRef(null);
  const scanTimeouts = useRef([]);

  const clearScanTimeouts = () => {
    scanTimeouts.current.forEach(clearTimeout);
    scanTimeouts.current = [];
  };

  // Violent localized shake for malicious threat execution.
  const triggerThreatShake = () => {
    shakeX.value = withSequence(
      withRepeat(withTiming(-6, { duration: 35 }), 4, true),
      withTiming(0, { duration: 40 })
    );
    shakeY.value = withSequence(
      withRepeat(withTiming(5, { duration: 32 }), 4, true),
      withTiming(0, { duration: 40 })
    );
    portalShakeX.value = withSequence(
      withRepeat(withTiming(-22, { duration: 28 }), 12, true),
      withRepeat(withTiming(18, { duration: 22 }), 10, true),
      withTiming(0, { duration: 70 })
    );
    portalShakeY.value = withSequence(
      withRepeat(withTiming(14, { duration: 24 }), 10, true),
      withRepeat(withTiming(-12, { duration: 26 }), 8, true),
      withTiming(0, { duration: 70 })
    );
  };

  // Ambient neon pulse states
  useEffect(() => {
    if (appState === 'IDLE') {
      portalScale.value = withRepeat(withTiming(1.08, { duration: 1200 }), -1, true);
    } else if (appState === 'SCANNING') {
      portalScale.value = withRepeat(withTiming(1.2, { duration: 300 }), -1, true);
    } else {
      portalScale.value = withTiming(1, { duration: 300 });
    }
  }, [appState]);

  useEffect(() => {
    radarRotation.value = withRepeat(
      withTiming(360, { duration: 18000, easing: Easing.linear }),
      -1,
      false
    );
  }, []);

  useEffect(() => {
    return () => clearScanTimeouts();
  }, []);

  useEffect(() => {
    const pulseId = setInterval(() => setDigitFlash(prev => !prev), appState === 'SCANNING' ? 160 : 420);
    return () => clearInterval(pulseId);
  }, [appState]);

  const handleScan = () => {
    if (!input.trim() || appState === 'SCANNING') return;
    const cleanInput = input.toLowerCase().trim();
    const looksThreatening = THREAT_NAMES.some(name => cleanInput.includes(name));
    
    clearScanTimeouts();
    setAppState('SCANNING');
    setTerminalLogs([]);
    flashOpacity.value = 0;
    if (looksThreatening) triggerThreatShake();
    
    // Fast-feed tech jargon loops
    JARGON_BANK.forEach((log, index) => {
      const timeoutId = setTimeout(() => {
        setTerminalLogs(prev => [...prev, `[${new Date().toLocaleTimeString()}] ${log}`]);
        scrollViewRef.current?.scrollToEnd({ animated: true });
      }, index * TERMINAL_INTERVAL_MS);
      scanTimeouts.current.push(timeoutId);
    });

    // Evaluate clean inputs vs explosive outcomes
    const resultTimeout = setTimeout(() => {
      if (SAFE_ARTIFACTS.includes(cleanInput) && !looksThreatening) {
        setAppState('SAFE');
        flashOpacity.value = withSequence(withTiming(0.7, { duration: 100 }), withTiming(0, { duration: 800 }));
      } else {
        setAppState('BURNT');
        triggerThreatShake();
      }
    }, JARGON_BANK.length * TERMINAL_INTERVAL_MS + 240);
    scanTimeouts.current.push(resultTimeout);
  };

  const resetScanner = () => {
    clearScanTimeouts();
    setAppState('IDLE');
    setInput('');
    setTerminalLogs([]);
  };

  const animatedRootStyle = useAnimatedStyle(() => ({
    transform: [{ translateX: shakeX.value }, { translateY: shakeY.value }]
  }));
  const animatedPortalStyle = useAnimatedStyle(() => ({
    transform: [{ translateX: portalShakeX.value }, { translateY: portalShakeY.value }, { scale: portalScale.value }]
  }));
  const animatedRadarStyle = useAnimatedStyle(() => ({
    transform: [{ rotate: `${radarRotation.value}deg` }]
  }));
  const animatedFlashStyle = useAnimatedStyle(() => ({ opacity: flashOpacity.value }));

  const getThemeColor = () => {
    if (appState === 'SCANNING') return digitFlash ? '#8AF7FF' : '#00BFFF';
    if (appState === 'SAFE') return '#00FF66';
    if (appState === 'BURNT') return '#FF0055';
    return '#00F0FF';
  };

  const getDigitColor = () => {
    if (appState === 'SCANNING') return digitFlash ? '#E6FDFF' : '#7DEEFF';
    if (appState === 'SAFE') return digitFlash ? '#D7FFE7' : '#00FF66';
    if (appState === 'BURNT') return digitFlash ? '#FFFFFF' : '#FF0055';
    return digitFlash ? '#C9FBFF' : '#00F0FF';
  };

  return (
    <Animated.View style={[styles.container, animatedRootStyle]}>
      <Animated.View pointerEvents="none" style={[styles.radarGrid, animatedRadarStyle]}>
        <RadarGrid />
      </Animated.View>
      <View pointerEvents="none" style={styles.staticScanlines} />
      <View style={styles.webCard}>
        <Animated.View style={[styles.flashOverlay, animatedFlashStyle, { backgroundColor: getThemeColor() }]} />

        {/* TOP HEADER SECTION */}
        <View style={styles.header}>
          <View>
            <Text style={[styles.headerTitle, { color: getThemeColor() }]}>QUANTUM_FROG.v3</Text>
            <Text style={styles.subHeader}>UNVERIFIED ARTIFACT CONTAINMENT HUD</Text>
          </View>
          <View style={styles.badgeContainer}>
            <Text style={styles.priceText}>$18.00/mo</Text>
          </View>
        </View>

        {/* CENTRAL NEON PORTAL */}
        <View style={styles.centerContainer}>
          <Animated.View style={[styles.portalRing, animatedPortalStyle, { borderColor: getThemeColor(), shadowColor: getThemeColor() }]}>
            <LinearGradient colors={['#031313', '#050608', '#120005']} style={styles.portalInner}>
              <View style={[styles.portalOrbit, { borderColor: `${getThemeColor()}44` }]} />
              <View style={[styles.portalCore, { backgroundColor: `${getThemeColor()}16` }]} />
              <FrogAvatar digitColor={getDigitColor()} glowColor={getThemeColor()} />
              {appState === 'IDLE' && <Text style={styles.portalStatusText}>CORE SECURE</Text>}
              {appState === 'SCANNING' && (
                <View style={styles.scanningWrap}>
                  <Text style={[styles.portalStatusText, { color: '#00F0FF' }]}>SCANNING ARTIFACT...</Text>
                  <View style={[styles.laserLine, { backgroundColor: '#00F0FF', shadowColor: '#00F0FF' }]} />
                </View>
              )}
              {appState === 'SAFE' && <Text style={[styles.portalStatusText, { color: '#00FF66' }]}>PASSED</Text>}
              {appState === 'BURNT' && <Text style={[styles.portalStatusText, { color: '#FF0055' }]}>THREAT ANNIHILATED</Text>}
            </LinearGradient>
          </Animated.View>
        </View>

        {/* TERMINAL DATA LOGS */}
        <View style={styles.terminalContainer}>
          <ScrollView ref={scrollViewRef} style={styles.terminalScroll}>
            {terminalLogs.length === 0 && appState === 'IDLE' && IDLE_LOGS.map((log, index) => (
              <Text key={index} style={[styles.terminalText, { color: index % 2 ? '#00FF66' : '#00F0FF' }]}>{log}</Text>
            ))}
            {terminalLogs.map((log, index) => (
              <Text key={index} style={[styles.terminalText, { color: getThemeColor() }]}>{log}</Text>
            ))}
            {appState === 'SAFE' && (
              <View style={styles.successBlock}>
                <Text style={styles.successText}>[SUCCESS] SHIELD EXTENSIONS VERIFIED. PROXY CHANNEL COMPLETED.</Text>
              </View>
            )}
            {appState === 'BURNT' && (
              <View style={styles.dangerBlock}>
                <Text style={styles.dangerText}>[CRITICAL] PACKAGES INJECTED WITH MALWARE. DESTROYING INSTANCE DATA.</Text>
              </View>
            )}
          </ScrollView>
        </View>

        {/* CORE OPERATIONAL CONTROLS */}
        <View style={styles.controlFooter}>
          {appState === 'IDLE' || appState === 'SCANNING' ? (
            <View style={styles.inputWrapper}>
              <TextInput
                style={[styles.inputField, { borderColor: getThemeColor(), color: getThemeColor() }]}
                placeholder="Enter Unverified Artifact..."
                placeholderTextColor="#576266"
                value={input}
                onChangeText={setInput}
                editable={appState !== 'SCANNING'}
                autoCapitalize="none"
              />
              <TouchableOpacity style={[styles.scanButton, { backgroundColor: getThemeColor() }]} onPress={handleScan}>
                <Text style={styles.buttonText}>LAUNCH</Text>
              </TouchableOpacity>
            </View>
          ) : (
            <TouchableOpacity style={[styles.resetButton, { borderColor: getThemeColor() }]} onPress={resetScanner}>
              <Text style={[styles.resetButtonText, { color: getThemeColor() }]}>REBOOT QUANTUM SYSTEM</Text>
            </TouchableOpacity>
          )}
        </View>
      </View>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#010305', justifyContent: 'center', alignItems: 'center', overflow: 'hidden' },
  flashOverlay: { ...StyleSheet.absoluteFillObject, zIndex: 999, pointerEvents: 'none' },
  radarGrid: {
    position: 'absolute',
    width: Math.max(width, height) * 1.35,
    height: Math.max(width, height) * 1.35,
    opacity: 0.64
  },
  staticScanlines: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(0,240,255,0.025)'
  },
  webCard: {
    width: 440,
    height: 760,
    backgroundColor: 'rgba(3, 7, 10, 0.96)',
    borderWidth: 2,
    borderColor: '#0df0ff',
    borderRadius: 8,
    padding: 24,
    justifyContent: 'space-between',
    zIndex: 10,
    shadowColor: '#00F0FF',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.9,
    shadowRadius: 24
  },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', borderBottomWidth: 1, borderBottomColor: '#10272d', paddingBottom: 16 },
  headerTitle: { fontFamily: 'Courier', fontWeight: 'bold', fontSize: 18, letterSpacing: 1 },
  subHeader: { color: '#7ba3aa', fontFamily: 'Courier', fontSize: 9, marginTop: 4 },
  badgeContainer: {
    alignItems: 'flex-end',
    backgroundColor: 'rgba(0,255,102,0.12)',
    borderColor: '#00FF66',
    borderWidth: 1,
    borderRadius: 6,
    paddingHorizontal: 12,
    paddingVertical: 7,
    shadowColor: '#00FF66',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.9,
    shadowRadius: 10
  },
  priceText: { color: '#00FF66', fontWeight: 'bold', fontFamily: 'Courier', fontSize: 16, textShadowColor: 'rgba(0,255,102,0.65)', textShadowRadius: 10 },
  centerContainer: { flex: 1, justifyContent: 'center', alignItems: 'center', marginVertical: 26 },
  portalRing: {
    width: 268,
    height: 268,
    borderRadius: 134,
    borderWidth: 5,
    justifyContent: 'center',
    alignItems: 'center',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 1,
    shadowRadius: 34,
    backgroundColor: '#000',
    overflow: 'visible'
  },
  portalInner: { width: '92%', height: '92%', borderRadius: 123, justifyContent: 'center', alignItems: 'center', overflow: 'hidden' },
  portalOrbit: {
    position: 'absolute',
    width: '78%',
    height: '78%',
    borderRadius: 96,
    borderWidth: 1,
    borderStyle: 'dashed'
  },
  portalCore: {
    position: 'absolute',
    width: 82,
    height: 82,
    borderRadius: 41,
    shadowColor: '#00F0FF',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.8,
    shadowRadius: 18
  },
  frogAvatarShell: {
    width: 176,
    height: 176,
    zIndex: 2,
    marginTop: 8,
    marginBottom: 2,
    shadowColor: '#00F0FF',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.65,
    shadowRadius: 18
  },
  portalStatusText: {
    color: '#fff',
    fontFamily: 'Courier',
    fontWeight: 'bold',
    fontSize: 11,
    textAlign: 'center',
    letterSpacing: 1,
    zIndex: 3,
    textShadowColor: 'rgba(0,240,255,0.78)',
    textShadowRadius: 8
  },
  scanningWrap: { alignItems: 'center', width: '100%', zIndex: 3 },
  laserLine: { width: '100%', height: 2, marginTop: 10, shadowOffset: { width: 0, height: 0 }, shadowOpacity: 1, shadowRadius: 10 },
  terminalContainer: {
    height: 176,
    backgroundColor: 'rgba(1, 8, 8, 0.96)',
    borderWidth: 1,
    borderColor: '#00F0FF',
    borderRadius: 6,
    padding: 14,
    marginBottom: 15,
    shadowColor: '#00F0FF',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.45,
    shadowRadius: 12
  },
  terminalScroll: { flex: 1 },
  terminalText: { fontFamily: 'Courier', fontSize: 11, marginBottom: 6, letterSpacing: 0 },
  successBlock: { marginTop: 12, backgroundColor: 'rgba(0,255,102,0.08)', padding: 10, borderWidth: 1, borderColor: '#00FF66', borderRadius: 4 },
  successText: { color: '#00FF66', fontFamily: 'Courier', fontSize: 11, fontWeight: 'bold' },
  dangerBlock: { marginTop: 12, backgroundColor: 'rgba(255,0,85,0.1)', padding: 10, borderWidth: 1, borderColor: '#FF0055', borderRadius: 4 },
  dangerText: { color: '#FF0055', fontFamily: 'Courier', fontSize: 11, fontWeight: 'bold', textShadowColor: 'rgba(255,0,85,0.55)', textShadowRadius: 8 },
  controlFooter: { marginBottom: 5 },
  inputWrapper: { flexDirection: 'row', height: 48 },
  inputField: {
    flex: 1,
    borderWidth: 1,
    borderRadius: 6,
    paddingHorizontal: 14,
    fontFamily: 'Courier',
    fontSize: 12,
    backgroundColor: '#020506',
    shadowColor: '#00F0FF',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.35,
    shadowRadius: 8
  },
  scanButton: { width: 96, justifyContent: 'center', alignItems: 'center', borderRadius: 6, marginLeft: 10 },
  buttonText: { color: '#000', fontWeight: 'bold', fontFamily: 'Courier', fontSize: 13, letterSpacing: 1 },
  resetButton: { height: 48, borderWidth: 1, borderRadius: 6, justifyContent: 'center', alignItems: 'center', backgroundColor: '#020202' },
  resetButtonText: { fontWeight: 'bold', fontFamily: 'Courier', fontSize: 12, letterSpacing: 1 }
});

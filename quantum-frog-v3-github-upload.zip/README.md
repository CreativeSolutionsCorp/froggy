# Quantum Frog

This is an Expo-based React Native app with a hyper-visual security dashboard UI.

## Setup

1. Install Node.js from https://nodejs.org/
2. Open a terminal in `c:\Users\marqu\Quantum Frog`
3. Run:
   ```bash
   npm install
   npm start
   ```

## Notes

- `App.js` uses `react-native-reanimated` and `expo-linear-gradient`.
- `package.json`, `app.json`, and `babel.config.js` are configured for Expo SDK 48.
